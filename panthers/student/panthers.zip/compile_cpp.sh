g++ -std=c++11 -O2 -Wall -static sol.cpp grader.cpp -o panther
